<!-- Service Start -->
<div class="container-xxl py-5">
    <div class="container py-5 px-lg-5">
        <div class="wow fadeInUp" data-wow-delay="0.1s">
            <p class="section-title text-secondary justify-content-center"><span></span>Our Services<span></span></p>
            <h1 class="text-center mb-5">What Security Solutions we Provide</h1>
        </div>
        <div class="row g-4">
            <div class="col-lg-4 col-md-4 wow fadeInUp" data-wow-delay="0.1s">
                <div class="service-item d-flex flex-column text-center rounded">
                    <div class="service-icon flex-shrink-0">
                    <img src="img/dome_camera.jpg" width="160px" class="img-fluid rounded-circle" alt="">

                    </div>
                    <h5 class="my-3">DOME Camera</h5>
                    <a class="btn btn-square" href=""><i class="fa fa-arrow-right"></i></a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                <div class="service-item d-flex flex-column text-center rounded">
                    <div class="service-icon flex-shrink-0">
                    <img src="img/bullet_camera.jpg" width="160px" class="img-fluid rounded-circle" alt="">

                    </div>
                    <h5 class="my-3">Bullet Camera</h5>
                    <a class="btn btn-square" href=""><i class="fa fa-arrow-right"></i></a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="service-item d-flex flex-column text-center rounded">
                    <div class="service-icon flex-shrink-0">
                    <img src="img/ip_camera.jpg" width="160px" class="img-fluid rounded-circle" alt="">

                    </div>
                    <h5 class="my-3">IP Camera</h5>
                    <a class="btn btn-square" href=""><i class="fa fa-arrow-right"></i></a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="service-item d-flex flex-column text-center rounded">
                    <div class="service-icon flex-shrink-0">
                    <img src="img/night_vision_camera.jpg" width="160px" class="img-fluid rounded-circle" alt="">

                    </div>
                    <h5 class="my-3">Night Vision Camera</h5>
                    <a class="btn btn-square" href=""><i class="fa fa-arrow-right"></i></a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                <div class="service-item d-flex flex-column text-center rounded">
                    <div class="service-icon flex-shrink-0">
                    <img src="img/simulated_camera.jpg" width="160px" class="img-fluid rounded-circle" alt="">

                    </div>
                    <h5 class="my-3">Simulated Camera</h5>
                    <a class="btn btn-square" href=""><i class="fa fa-arrow-right"></i></a>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="service-item d-flex flex-column text-center rounded">
                    <div class="service-icon my-3 flex-shrink-0">
             <img src="img/turret_camera.jpg" width="160px" class="img-fluid rounded-circle" alt="">
                    </div>
                    <h5 class="my-3">Turret Camera</h5>
                    <a class="btn btn-square" href=""><i class="fa fa-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Service End -->


<!-- Newsletter Start -->
<div class="container-xxl bg-gradi newsletter py-4 wow fadeInUp" data-wow-delay="0.1s">
    <div class="container py-5 px-lg-5">
        <div class="row justify-content-center">
            <div class="col-lg-6 text-center">
                <p class="section-title text-secondary justify-content-center"><span></span>Enquiry Form<span></span></p>
                <h1 class="text-center text-white mb-4">Enquiry Form</h1>

                <form method="POST">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="form-floating form-floating-sm">
                                <input type="text" class="form-control" required name="name" id="name" placeholder="Customer Name">
                                <label for="name">Customer Name</label>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-floating form-floating-sm">
                                <input type="number" class="form-control" required name="number" id="number" placeholder="Contact Number">
                                <label for="number">Contact Number</label>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-floating form-floating-sm">
                                <input type="email" class="form-control" required name="email" id="email" placeholder="Your Email">
                                <label for="email">Your Email</label>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-floating form-floating-sm">
                                <select name="product" required class="form-select" id="">
                                    <option value="" selected disabled>Select Product</option>
                                    <option value="Product2">Product 2</option>
                                    <option value="Product3">Product 3</option>
                                    <option value="Product4">Product 4</option>
                                    <option value="Product5">Product 5</option>
                                    <option value="Product6">Product 6</option>
                                </select>

                                <label for="email">Select Product</label>

                            </div>
                        </div>



                        <div class="col-12">
                            <div class="form-floating form-floating-sm">
                                <textarea class="form-control" name="address" required placeholder="Customer Address" id="message" style="height: 80px"></textarea>
                                <label for="message">Address</label>
                            </div>
                        </div>
                        <div class="col-12">
                            <button class="btn btn-secondary text-white w-100 py-3" name="send" type="submit">Send Message</button>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>
<!-- Newsletter End -->

<!-- Testimonial Start -->
<div class="container-xxl py-5" id="review">
    <div class="container py-5 px-lg-5">

        <div class="wow fadeInUp" data-wow-delay="0.1s">
            <p class="section-title text-secondary justify-content-center"><span></span>Testimonials<span></span></p>
            <h1 class="text-center mb-5">What Say Our Clients !</h1>
        </div>
        <div class="owl-carousel testimonial-carousel wow fadeInUp" data-wow-delay="0.1s">
            
        <?php
        $select = mysqli_query($con, "SELECT * FROM `testimonials` ");
        while($run = mysqli_fetch_array($select)){
            ?>
               <div class="testimonial-item rounded p-4">
                <div class="d-flex align-items-center mb-4">
                    <!-- <img class="img-fluid bg-white rounded flex-shrink-0 p-1" src="img/testimonial-1.jpg" style="width: 85px; height: 85px;"> -->
                    <div class="ms-4">
                        <h5 class="mb-1"><?= $run['name'] ?></h5>
                        <!-- <p class="mb-1">Profession</p> -->
                        <div>
                            <small class="fa fa-star text-warning"></small>
                            <small class="fa fa-star text-warning"></small>
                            <small class="fa fa-star text-warning"></small>
                            <small class="fa fa-star text-warning"></small>
                            <small class="fa fa-star text-warning"></small>
                        </div>
                    </div>
                </div>
                <p class="mb-0"><?= $run['review'] ?></p>
            </div>
            <?php
        }
        ?>

         
       
        </div>
    </div>
</div>
<!-- Testimonial End -->

<?php
if (isset($_POST['send'])) {
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $number = mysqli_real_escape_string($con, $_POST['number']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $address = mysqli_real_escape_string($con, $_POST['address']);
    $product = mysqli_real_escape_string($con, $_POST['product']);

    $insert = mysqli_query($con, "INSERT INTO `enquiries`(`name`, `number`,`email`, `address`, `product`, `time`) VALUES ('$name','$number','$email','$address','$product',current_timestamp() )");


    if ($insert) {
        echo '<script>alert("Enquiry Sent..!")</script>';
        echo '<script>window.location.href = window.location </script>';
    } else {
        echo "<script>alert('Something Went Wrong..!')</script>";
    }
}
?>