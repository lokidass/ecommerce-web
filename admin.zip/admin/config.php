
<?php 



$con = mysqli_connect('localhost','kamal_anand_cctv','Kamal@123#','kamal_cctv') or die("database not connected..!");
// $con = mysqli_connect('localhost','dnyanpath','Dnyanpath@1234','dnyanpathpublication') or die("database not connected..!");

?>