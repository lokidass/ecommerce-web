<?php include('header.php') ?>

<div class="container-xxl bg-primary hero-header">
    <div class="container px-lg-5">
        <div class="row g-5 align-items-end">
            <div class="col-lg-7 text-center text-lg-start">
                <h1 class="text-white mb-4 animated slideInDown">Security solutions for your work and home.</h1>
                <p class="text-white pb-3 animated slideInDown">Tempor rebum no at dolore lorem clita rebum rebum ipsum rebum stet dolor sed justo kasd. Ut dolor sed magna dolor sea diam. Sit diam sit justo amet ipsum vero ipsum clita lorem</p>
                <a href="Customer_Support" class="btn btn-secondary text-white py-sm-3 px-sm-5 rounded-pill me-3 animated slideInLeft">Customer Help</a>

                <button class="btn btn-light py-sm-3 px-sm-5 rounded-pill animated slideInRight" data-bs-toggle="modal" data-bs-target="#exampleModal">Write a Review</button>

            </div>
            <div class="col-lg-5 text-center text-lg-start">
                <!-- <img class="img-fluid animated zoomIn" src="img/1.png" alt=""> -->
                <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="img/1.jpg" class="rounded d-block w-100" alt="slider.images">
                        </div>
                        <div class="carousel-item">
                            <img src="img/2.jpg" class="rounded d-block w-100" alt="slider.images">
                        </div>
                        <div class="carousel-item">
                            <img src="img/3.jpg" class="rounded d-block w-100" alt="slider.images">
                        </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>


</div>

<!-- Button trigger modal -->
<!-- <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
  Launch demo modal
</button> -->

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Write a Review</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="text" class="form-control" required name="name" id="name" placeholder="Customer Name">
                                <label for="name">Your Name</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-floating">
                                <input type="text" class="form-control" required name="number" id="number" placeholder="Contact Number">
                                <label for="number">Mobile Number</label>
                            </div>
                        </div>
                    

                        <div class="col-12">
                            <div class="form-floating">
                                <textarea class="form-control" name="review" required placeholder="Type a Review" id="message" style="height: 130px"></textarea>
                                <label for="message">Write a Review</label>
                            </div>
                        </div>
                        <div class="col-12">
                            <button class="btn btn-primary w-100 py-3" name="submit" type="submit">Submit Review</button>
                        </div>
                    </div>
                </form>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary text-white" data-bs-dismiss="modal">Close</button>
                <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
            </div>
        </div>
    </div>
</div>

<?php include('about_content.php') ?>
<?php include('services_content.php') ?>
<?php include('products_content.php') ?> 
<?php include('contactform.php') ?>
<?php include('footer.php') ?>

<?php


if (isset($_POST['submit'])) {
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $number = mysqli_real_escape_string($con, $_POST['number']);
    $review = mysqli_real_escape_string($con, $_POST['review']);

    $insert = mysqli_query($con, "INSERT INTO `review`(`name`, `number`, `review`, `time`) VALUES ('$name','$number','$review',current_timestamp() )");

    if ($insert) {
        echo '<script>alert("Review Sent..!")</script>';
        echo '<script>window.location.href = window.location </script>';
    } else {
        echo "<script>alert('Something Went Wrong..!')</script>";
    }
}
?>